ALTER TABLE `mdr` ADD `mdr_lic` VARCHAR( 200 ) NOT NULL AFTER `mdr_siret` ;
ALTER TABLE `mdr` ADD `mdr_siteweb` VARCHAR( 200 ) NOT NULL AFTER `_isdeleted` ;