<li>
	<div class="updatethumb"><img src="images/thumbs/avatar15.png" alt="" /></div>
	<div class="updatecontent">
		<div class="top">
			<a href="" class="user">Juan Dela Cruz</a> - <a href="">0 Comment</a> - 
			<a href="">Share</a> - <a href="">Report</a> - <span>Just now</span>
		</div><!--top-->
		<div class="text">
			<?php echo nl2br($_POST['message']); ?>
		</div><!--text-->
	</div><!--updatecontent-->
</li>
