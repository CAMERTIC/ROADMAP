<ul>
	<li><a href="#formsub" class="editor">MY TASKS</a>
		<span class="arrow"></span>
		<ul id="formsub">
			<li><a href="?view=my-tasks">ALL</a></li>
			<li><a href="wizard.html">Pending</a></li>
			<li><a href="editor.html">Closed</a></li>
			<li><a href="#">Not Open</a></li>
		</ul>
	</li>
	<li><a href="#addons" class="addons">Conditions</a>
		<span class="arrow"></span>
		<ul id="addons">
			<li><a href="#">6 months</a></li>
			<li><a href="#">12 months</a></li>
			<li><a href="#">18 months</a></li>
		</ul>
	</li>
	<li><a href="#error" class="error">Construction</a>
		<span class="arrow"></span>
		<ul id="error">
			<li><a href="#">6 months</a></li>
			<li><a href="#">12 months</a></li>
			<li><a href="#">18 months</a></li>
		</ul>
	</li>
	<li><a href="#add" class="typo">Exploitation</a>
		<span class="arrow"></span>
		<ul id="add">
			<li><a href="#">6 months</a></li>
			<li><a href="#">12 months</a></li>
			<li><a href="#">18 months</a></li>
		</ul>
	</li>
</ul>
<a class="togglemenu"></a>
<br /><br />