<ul>
	<li><a href="#formsub" class="editor">ALL TASKS</a>
		<span class="arrow"></span>
		<ul id="formsub">
			<li><a href="all-tasks-admin.php">6 months</a></li>
			<li><a href="#">12 months</a></li>
			<li><a href="#">18 months</a></li>
			<li><a href="#">Upload Sheet</a></li>
			<li><a href="#">Create new</a></li>
		</ul>
	</li>
	<li><a href="#addons" class="addons">Conditions</a>
		<span class="arrow"></span>
		<ul id="addons">
			<li><a href="#">6 months</a></li>
			<li><a href="#">12 months</a></li>
			<li><a href="#">18 months</a></li>
		</ul>
	</li>
	<li><a href="#error" class="error">Construction</a></li>
	<li><a href="#add" class="typo">Exploitation</a></li>
	<li><a href="#users" class="editor">Users</a>
		<span class="arrow"></span>
		<ul id="users">
			<li><a href="#">All users</a></li>
			<li><a href="#">Logs</a></li>
		</ul>
	</li>
	<li><a href="#set" class="editor">Settings</a>
		<span class="arrow"></span>
		<ul id="set">
			<li><a href="#">Mail</a></li>
			<li><a href="#">parameters</a></li>
			<li><a href="#">print reports</a></li>
		</ul>
	</li>
</ul>
<a class="togglemenu"></a>
<br /><br />