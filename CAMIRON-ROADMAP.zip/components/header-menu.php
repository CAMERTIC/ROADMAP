<ul class="headermenu">
	<li class="current"><a href="dashboard.php"><span class="icon icon-flatscreen"></span>Dashboard</a></li>
	<li><a href="manageblog.html"><span class="icon icon-pencil"></span>Tasks</a></li>
	<li><a href="messages.html"><span class="icon icon-message"></span> LAST Comments</a></li>
</ul>