<ul class="headermenu">
	<li class="current"><a href="dashboard-admin.php"><span class="icon icon-flatscreen"></span>Dashboard</a></li>
	<li><a href="manageblog.html"><span class="icon icon-pencil"></span>Tasks</a></li>
	<li><a href="messages.html"><span class="icon icon-message"></span>Comments</a></li>
	<li><a href="reports.html"><span class="icon icon-chart"></span>Reports</a></li>
</ul>